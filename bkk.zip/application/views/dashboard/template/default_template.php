<!DOCTYPE html>
<html>
    <?php echo $page["head"]; ?>
    <?php echo $page["sidebar"]; ?>
	<div class="app-main" id="main">
    	<div class="container-fluid">
	    	<?php echo $content; ?>
    <?php echo $page["footer"]; ?>
		</div>
	</div>
</body>
</html>