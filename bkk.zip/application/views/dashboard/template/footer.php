<!-- begin footer -->
<footer class="footer">
    <div class="row">
        <div class="col-12 col-sm-6 text-center text-sm-left">
            <p>&copy; Copyright 2019. All rights reserved.</p>
        </div>
        <div class="col  col-sm-6 ml-sm-auto text-center text-sm-right">
            <p>Copy Right by Frais Mediatech</p>
        </div>
    </div>
</footer>
<!-- end footer -->