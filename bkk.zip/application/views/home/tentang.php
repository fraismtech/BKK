<section class="ftco-section mt-4">
  <div class="container">
    <h4 class="ftco-animate mb-3"><b>Tentang Kami</b></h4>
    <div class="row d-flex justify- ftco-animate">
      <div class="col-lg-12 mt-3">
      	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua.  :
      	</p>
      	<ul>
      		<li>1.Terminal Kayuagung Type C.</li>
      		<li>2.Kantor Telekomunikasi Cabang Kayuagung.</li>
      		<li>3.Kantor PLN Ranting Kayuagung.</li>
      		<li>4.Jembatan dan Jalan Tol Jakabaring Kayuagung.</li>
      	</ul>
      	<p> Sehingga dengan adanya sarana dan prasarana insfrastruktur tersebut dapat memudahkan untuk menjangkau daerah lahan investasi bagi investor untuk berinvestasi.</p>
     </div>
   </div>
 </div>
</section>