<section class="ftco-section mt-4">
 <div class="container">
  <br>
  <div class="row d-flex ftco-animate justify-content-center">
    <div class="col-md-4 d-flex ftco-animate fadeInUp ftco-animated">
      <div class="blog-entry justify-content-end w-100">
        <a href="<?php echo base_url(); ?>Bkk/kegiatanDetail" class="block-20" style="background-image: url('<?php echo base_url(); ?>assets/home/images/bg_2.jpg');">
        </a>
        <div class="text mt-3 mb-3 float-right d-block">
          <h3 class="heading"><a href="<?php echo base_url(); ?>Bkk/kegiatanDetail">Lorem ipsum dolor sit amet, consectetur adipisicing elit</a></h3>
          <p class="text-justify">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
          tempor incididunt ut labore et dolore magna aliqua.</p>
          <a href="<?php echo base_url(); ?>Bkk/kegiatanDetail" class="btn btn-info float-right">Selengkapnya</a>
        </div>
      </div>
    </div>
    <div class="col-md-4 d-flex ftco-animate fadeInUp ftco-animated">
      <div class="blog-entry justify-content-end w-100">
        <a href="<?php echo base_url(); ?>Bkk/kegiatanDetail" class="block-20" style="background-image: url('<?php echo base_url(); ?>assets/home/images/bg_2.jpg');">
        </a>
        <div class="text mt-3 mb-3 float-right d-block">
          <h3 class="heading"><a href="<?php echo base_url(); ?>Bkk/kegiatanDetail">Lorem ipsum dolor sit amet, consectetur adipisicing elit</a></h3>
          <p class="text-justify">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
          tempor incididunt ut labore et dolore magna aliqua.</p>
          <a href="<?php echo base_url(); ?>Bkk/kegiatanDetail" class="btn btn-info float-right">Selengkapnya</a>
        </div>
      </div>
    </div>
    <div class="col-md-4 d-flex ftco-animate fadeInUp ftco-animated">
      <div class="blog-entry justify-content-end w-100">
        <a href="<?php echo base_url(); ?>Bkk/kegiatanDetail" class="block-20" style="background-image: url('<?php echo base_url(); ?>assets/home/images/bg_2.jpg');">
        </a>
        <div class="text mt-3 mb-3 float-right d-block">
          <h3 class="heading"><a href="<?php echo base_url(); ?>Bkk/kegiatanDetail">Lorem ipsum dolor sit amet, consectetur adipisicing elit</a></h3>
          <p class="text-justify">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
          tempor incididunt ut labore et dolore magna aliqua.</p>
          <a href="<?php echo base_url(); ?>Bkk/kegiatanDetail" class="btn btn-info float-right">Selengkapnya</a>
        </div>
      </div>
    </div>
    <div class="col-md-4 d-flex ftco-animate fadeInUp ftco-animated">
      <div class="blog-entry justify-content-end w-100">
        <a href="<?php echo base_url(); ?>Bkk/kegiatanDetail" class="block-20" style="background-image: url('<?php echo base_url(); ?>assets/home/images/bg_2.jpg');">
        </a>
        <div class="text mt-3 mb-3 float-right d-block">
          <h3 class="heading"><a href="<?php echo base_url(); ?>Bkk/kegiatanDetail">Lorem ipsum dolor sit amet, consectetur adipisicing elit</a></h3>
          <p class="text-justify">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
          tempor incididunt ut labore et dolore magna aliqua.</p>
          <a href="<?php echo base_url(); ?>Bkk/kegiatanDetail" class="btn btn-info float-right">Selengkapnya</a>
        </div>
      </div>
    </div>
    <div class="col-md-4 d-flex ftco-animate fadeInUp ftco-animated">
      <div class="blog-entry justify-content-end w-100">
        <a href="<?php echo base_url(); ?>Bkk/kegiatanDetail" class="block-20" style="background-image: url('<?php echo base_url(); ?>assets/home/images/bg_2.jpg');">
        </a>
        <div class="text mt-3 mb-3 float-right d-block">
          <h3 class="heading"><a href="<?php echo base_url(); ?>Bkk/kegiatanDetail">Lorem ipsum dolor sit amet, consectetur adipisicing elit</a></h3>
          <p class="text-justify">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
          tempor incididunt ut labore et dolore magna aliqua.</p>
          <a href="<?php echo base_url(); ?>Bkk/kegiatanDetail" class="btn btn-info float-right">Selengkapnya</a>
        </div>
      </div>
    </div>
  </div>
  <ul class="pagination text-center justify-content-center">
    <li class="page-item"><a class="page-link" href="#">Previous</a></li>
    <li class="page-item"><a class="page-link" href="#">1</a></li>
    <li class="page-item active"><a class="page-link" href="#">2</a></li>
    <li class="page-item"><a class="page-link" href="#">3</a></li>
    <li class="page-item"><a class="page-link" href="#">Next</a></li>
  </ul>
</div>
</section>